package br.ufal.ic.ppgi.smartagenda.bloqueioMgt.impl;

import java.util.List;

import br.ufal.ic.ppgi.smartagenda.bloqueioMgt.spec.prov.IManager;

//proteção padrão do Java. Apenas quem está no mesmo package pode ver.

class Manager implements IManager{

	public List<String> getProvidedInterfaces() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<String> getRequiredInterfaces() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getProvidedInterfaces(String interfaceName) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getRequiredInterfaces(String interfaceName) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setRequiredInterface(String interfaceName, Object objeto) {
		// TODO Auto-generated method stub
		
	}
	

}
